/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.ArrayList;
import models.Classe;
import models.Etudiant;
import models.Personne;
import models.Professeur;




/**
 *
 * @author hp
 */
public class ServiceListDetail {
    public static final ArrayList<Professeur> listeProfesseur= new ArrayList<Professeur>();
     ArrayList<Personne> bd = new ArrayList<Personne>();

    public ServiceListDetail() {
        
    }
     
     
     
     public boolean creerPersonne(Professeur p){
        listeProfesseur.add(p);
        return true;
    }

    public ArrayList<Professeur> listerProfesseur() {
        return listeProfesseur;
    }
   
    
    public static final ArrayList<Etudiant> listeEtudiant= new ArrayList<Etudiant>();
   
     public boolean creerPersonne(Etudiant e){
        listeEtudiant.add(e);
        return true;
    }

    public ArrayList<Etudiant> listerEtudiant() {
        return listeEtudiant;
    }
    
    public static final ArrayList<Classe> listeClasse= new ArrayList<Classe>();
    
     public boolean creerClasse(Classe c){
        listeClasse.add(c);
        return true;
    }

    public ArrayList<Classe> listerClasse() {
        return listeClasse;
    }
    
   

    
    
}
