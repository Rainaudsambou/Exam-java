/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.ArrayList;
import models.Classe;
import models.Detail;
import models.Etudiant;
import models.Inscription;
import models.Personne;
import models.Professeur;

/**
 *
 * @author hp
 */
public interface IPersonne {
    public boolean creerPersonne(Professeur p);
    public ArrayList<Professeur> listerProfesseur();
    public static final ArrayList<Etudiant> listeEtudiant= new ArrayList<Etudiant>();
    public int creerPersonne(Etudiant e);
    public ArrayList<Etudiant> listerEtudiant();
    public static final ArrayList<Classe> listeClasse= new ArrayList<Classe>();
    public boolean creerClasse(Classe c);
    public ArrayList<Classe> listerClasse();
     
    public Etudiant getEtudiantById(int id);
    public Professeur getProfByNumero(String numero);
    
    public ArrayList<Professeur> getListProfByNumero(String numero);
     public ArrayList<Detail> getDetailByNumeroAndYear(String numero, Professeur p);
    public boolean creerAffectation(Detail det);
    public boolean creerInscription( Inscription i);
    
}
