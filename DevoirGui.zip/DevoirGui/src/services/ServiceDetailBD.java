/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.ClasseDao;
import dao.DetailDao;
import dao.EtudiantDao;
import dao.InscriptionDao;
import dao.ProfesseurDao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Classe;
import models.Detail;
import models.Etudiant;
import models.Inscription;
import models.Personne;
import models.Professeur;

/**
 *
 * @author Cristèle
 */
public class ServiceDetailBD implements IPersonne {

    private InscriptionDao daoInscription;
    private EtudiantDao daoEtudiant;
    private ClasseDao daoClasse;
    private ProfesseurDao daoProf;
    private DetailDao daoDetail;
    
    public ServiceDetailBD(){
        daoInscription = new InscriptionDao();
        daoEtudiant = new EtudiantDao();
        daoClasse = new ClasseDao();
        daoProf = new ProfesseurDao();
        daoDetail = new DetailDao();
    }
    @Override
    public boolean creerPersonne(Professeur p) {
        return daoProf.create(p) != 0;
    }

    @Override
    public ArrayList<Professeur> listerProfesseur() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int creerPersonne(Etudiant e) {
        return daoEtudiant.create(e) ;
    }

    @Override
    public ArrayList<Etudiant> listerEtudiant() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean creerClasse(Classe c) {
        return daoClasse.create(c) != 0;
    }

    @Override
    public ArrayList<Classe> listerClasse() {
        return daoClasse.selectAll();
    }

    @Override
    public boolean creerInscription( Inscription i) {
       if (i.getEtudiant().getId()== 0){
           int id = daoEtudiant.create(i.getEtudiant());
           i.getEtudiant().setId(id);
       }
       return daoInscription.create(i)!= 0;
    }

    @Override
    public Etudiant getEtudiantById(int id) {
        return daoEtudiant.selectById(id);
    }

    @Override
    public Professeur getProfByNumero(String numero) {
        return daoProf.selectByNumero(numero);
    }
    @Override
    public boolean creerAffectation(Detail det){
        return daoDetail.create(det) != 0;
    }

    @Override
    public ArrayList<Professeur> getListProfByNumero(String numero) {
        List <Professeur> p = null;
        try {
            p =  daoProf.ListProfByNumero(numero);
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDetailBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return (ArrayList<Professeur>) p;
    }

    @Override
    public ArrayList<Detail> getDetailByNumeroAndYear(String numero, Professeur p) {
        List <Detail> d = null;
        try {
            
            d = daoDetail.selectClasseByProf(numero, p);
            
           
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDetailBD.class.getName()).log(Level.SEVERE, null, ex);
        }
         return  (ArrayList<Detail>) d;
    }
    
}
