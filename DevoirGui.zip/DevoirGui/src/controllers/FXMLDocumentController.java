/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import models.Classe;
import models.Detail;
import models.Etudiant;
import models.Inscription;
import models.Personne;
import models.Professeur;
import services.IPersonne;
import services.ServiceDetailBD;
import services.ServiceListDetail;

/**
 *
 * @author hp
 */
public class FXMLDocumentController implements Initializable {
    
    
    @FXML
    private ComboBox<Classe> cboClasse;
    @FXML
    private ComboBox<String> cboAnneeScol;
    @FXML
    private ComboBox<String> cboClass;
    @FXML
    private ComboBox<String> cboAnnee;
    @FXML
    private TextField txtNumero;
    @FXML
    private Button btnInscrireEtudiant;
    @FXML
    private TableView<Etudiant> tblVInfoEtudiant;
    @FXML
    private TableColumn<Etudiant, String> tbleNom;
    @FXML
    private TableColumn<Etudiant, String> tblePrenom;
    @FXML
    private TableColumn<Etudiant, String> tbleClasse;
    @FXML
    private TableColumn<Etudiant, Date> tbleAnneeScol;
    
    private ServiceListDetail service;
    
    ObservableList<Etudiant> obEtudiants;
    private Etudiant et;
    @FXML
    private Button btnSearchClasse;
    @FXML
    //private TableColumn<?, ?> tbleAnnezScol;;
    private TextField txtNom;
    @FXML
    private TextField txtPrenom;
    private IPersonne servicePerson;
    @FXML
    private TextField txtTuteur;
    @FXML
    private TextField txtLibelle;
    @FXML
    private Button btnAddClasse;
    @FXML
    private TableColumn<Classe, String> colId;
    @FXML
    private TableColumn<Classe, String> colLibelle;
    ObservableList<Classe> AllClass;
    ObservableList<Professeur> AllProfRecherhcer;
    ObservableList<Classe> ClassesInscription;
     ObservableList<Detail> DetailRechercher;
    @FXML
    private TableView<Classe> tblClasse;
    @FXML
    private TextField txtNumeroProf;
    @FXML
    private TextField txtNomProf;
    @FXML
    private TextField txtPrenomProf;
    @FXML
    private Button btnAddProf;
    @FXML
    private ComboBox<Classe> cboClasse1;
    @FXML
    private ComboBox<String> cboAnnee1;
    @FXML
    private TableView<Professeur> tblClasseProf;
    @FXML
    private TableColumn<Professeur, String> colLibelleClasseProf;
    @FXML
    private TextField txtGrade;
    @FXML
    private Button btnRechercherProfAaffecter;
    @FXML
    private TextField txtNumeroProfAassigner;
    @FXML
    private Button btnEnregistrerAff;
    Personne pAff = null; 
    Personne ProfARechercher = null;
    @FXML
    private TextField txtNumProfARechercher;
    @FXML
    private Button BtnSearchbtnToShow;
    @FXML
    private TableView<Professeur> tblProfRechercher;
    @FXML
    private TableColumn<Professeur, String> colName;
    @FXML
    private TableColumn<Professeur, String> colfirstname;
    @FXML
    private TableView<Detail> tblClasseRechercher;
    @FXML
    private ComboBox<String> cbxAnne;
    @FXML
    private TableColumn<Detail, String> colClassr;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        servicePerson = new ServiceDetailBD();
        ClassesInscription = FXCollections.observableArrayList(servicePerson.listerClasse() );
        cboClasse.setItems(ClassesInscription);
        cboClasse1.setItems(ClassesInscription);
        
        cboClass.getItems().add("LIAGE");
        cboClass.getItems().add("MAE");
        cboClass.getItems().add("TTL");
        cboClass.getItems().add("GLRS");
        
        cboAnneeScol.getItems().add("2017/2018");
        cboAnneeScol.getItems().add("2018/2019");
        cboAnneeScol.getItems().add("2019/2020");
        
        cboAnnee1.getItems().add("2018");
        cboAnnee1.getItems().add("2019");
        cboAnnee1.getItems().add("2020");
        
        cbxAnne.getItems().add("2018");
        cbxAnne.getItems().add("2019");
        cbxAnne.getItems().add("2020");
        
        service=new ServiceListDetail();
        ArrayList<Etudiant> etudiants=service.listerEtudiant();
        obEtudiants=FXCollections.observableArrayList(etudiants);
        tbleNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        tblePrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        tbleClasse.setCellValueFactory(new PropertyValueFactory<>("classe"));
        tblVInfoEtudiant.setItems(obEtudiants);
        
         LoadTableClasse();
        txtNumero.setText( GenererNumero("ETU"));
        txtNumeroProf.setText( GenererNumero("PROF"));
        
        
        // cacher combo date et annee dans affecter prof
        cboAnnee1.setVisible(false);
        cboClasse1.setVisible(false);
      
    } 
    public void LoadTableClasse(){
        ArrayList<Classe>classes= servicePerson.listerClasse();
        AllClass= FXCollections.observableArrayList(classes);
        colId.setCellValueFactory(new  PropertyValueFactory<>("id"));
        colLibelle.setCellValueFactory(new  PropertyValueFactory<>("libelle"));
        tblClasse.setItems(AllClass);
    }

   
    public static String GenererNumero(String person){
        
        Calendar c = Calendar.getInstance(); // date du jour 
        String auj = LocalDate.now().format(DateTimeFormatter.ofPattern("MM-yyyy"));
        Random r = new Random();
        int valeur = 100000 + r.nextInt(999999 - 100000);
        String num = person+"-"+valeur+"-"+auj; 
        return num;
    }

    
    @FXML
    private void handleInscrireEtudiantByNum(ActionEvent event) {
        String auj = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        
        Personne p = null;
        Classe cl = cboClasse.getSelectionModel().getSelectedItem();
        p = new Etudiant();
        p.setNom(txtNom.getText());
        p.setPrenom(txtPrenom.getText());
        p.setNumero(txtNumero.getText());
        p.setDateNaissance("");
        ((Etudiant)p).setTuteur(txtTuteur.getText());
        
        int id = servicePerson.creerPersonne((Etudiant)p);
        Inscription ins = null;
        if(id != 0){
            ins = new Inscription();
            
            ins.setAnneeScolaire(cboAnneeScol.getValue());
            
            ins.setClasse(cl);
            ins.setEtudiant(servicePerson.getEtudiantById(id));
            ins.setDate(auj);
            System.out.println(ins.toString());
            servicePerson.creerInscription(ins);
        }
    }

    @FXML
    private void handleSearchClasseEtudiant(ActionEvent event) {
        String classe= cboClass.getPromptText();
        String annee= cboAnnee.getPromptText();
        
                   
    }

    @FXML
    private void addClasse(ActionEvent event) {
          Classe classe;
        if(txtLibelle.getText() != ""){
            classe = new Classe();
            classe.setLibelle(txtLibelle.getText());
            if(servicePerson.creerClasse(classe)){
                Alert alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Classe Enregisté avec succees");
                alert.showAndWait();
                
                txtLibelle.setText("");
                 LoadTableClasse();
            }
        }
    }

    @FXML
    private void AddProfesseur(ActionEvent event) {
        Personne p = null;
        p = new Professeur();
        p.setNom(txtNomProf.getText());
        p.setPrenom(txtPrenomProf.getText());
        p.setNumero(txtNumeroProf.getText());
        p.setDateNaissance("");
        ((Professeur)p).setGrade(txtGrade.getText());
        
        
         if(servicePerson.creerPersonne((Professeur)p)){
                Alert alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Professeur Enregisté avec succees");
                alert.showAndWait();
                
                txtNomProf.setText("");
                txtPrenomProf.setText("");
                txtNumeroProf.setText("");
                txtGrade.setText("");
            }
    }

    @FXML
    private void searchProfToAssign(ActionEvent event) {

        if (txtNumeroProfAassigner.getText() != ""){
            pAff = new Professeur();
            pAff = servicePerson.getProfByNumero(txtNumeroProfAassigner.getText());
            System.out.println(pAff);
            if(pAff != null){
               cboAnnee1.setVisible(true);
                cboClasse1.setVisible(true);
            }
          
         
        }
    }

    @FXML
    private void EnregistrerAffectation(ActionEvent event) {
        Classe cl = cboClasse1.getSelectionModel().getSelectedItem();
         Detail det = new Detail(cboAnnee1.getValue(), cl, (Professeur) pAff);
        if(servicePerson.creerAffectation(det)){
            Alert alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Affectation Enregisté avec succees");
                alert.showAndWait();
        }
          
    }

    @FXML
    private void searchProfToshow(ActionEvent event) {
          if (txtNumProfARechercher.getText() != ""){
            ProfARechercher = new Professeur();
            ProfARechercher = servicePerson.getProfByNumero(txtNumProfARechercher.getText());
            
            if(ProfARechercher != null){
              ArrayList<Professeur>profs= servicePerson.getListProfByNumero(txtNumProfARechercher.getText());
            AllProfRecherhcer= FXCollections.observableArrayList(profs);
            colName.setCellValueFactory(new  PropertyValueFactory<>("nom"));
            colfirstname.setCellValueFactory(new  PropertyValueFactory<>("prenom"));
            tblProfRechercher.setItems(AllProfRecherhcer);
            }
          
    }
    
}

    @FXML
    private void ShowClassOfProf(MouseEvent event) {
        Professeur p = tblProfRechercher.getSelectionModel().getSelectedItem();
        if(cbxAnne.getValue() != ""){
             ArrayList<Detail>detail= servicePerson.getDetailByNumeroAndYear(cbxAnne.getValue(), p);
             System.out.println(detail.toString());
             DetailRechercher= FXCollections.observableArrayList(detail);
            colClassr.setCellValueFactory(new  PropertyValueFactory<>("classe"));
            tblClasseRechercher.setItems(DetailRechercher);
        
        }else{
             Alert alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Choisissez une année");
                alert.showAndWait();
        }
       
    }
}
    