/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Inscription;

/**
 *
 * @author ASUS
 */
public class InscriptionDao implements IDao<Inscription>{

    private final String SQL_ALL="Select * From inscription ";
    private final String SQL_INSERT="INSERT INTO `inscription` (`date`, `anneScolaire`, `classe`, `etudiant`) VALUES ( ?, ?, ?, ?);";
   
    private MySqlDB mysql;
    
    public InscriptionDao(){
       mysql=new MySqlDB();
    }
    
    @Override
    public int create(Inscription obj) {
        int result = 0;
        try {
            mysql.initPS(SQL_INSERT);
            mysql.getPstm().setString(1, obj.getDate());
            mysql.getPstm().setString(2, obj.getAnneeScolaire());
            mysql.getPstm().setInt(3, obj.getClasse().getId());
            mysql.getPstm().setInt(4,obj.getEtudiant().getId());
            
            //5 Execution de la requete
            result=mysql.executeMaj();
        } catch (SQLException ex) {
            Logger.getLogger(InscriptionDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return result;
    }

    @Override
    public boolean update(Inscription obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Inscription> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Inscription selectById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Inscription selectByNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
