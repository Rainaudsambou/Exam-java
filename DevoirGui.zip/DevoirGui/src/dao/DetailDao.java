/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Classe;
import models.Detail;
import models.Professeur;

/**
 *
 * @author ASUS
 */
public class DetailDao implements IDao<Detail>{

      private final String SQL_ALL="Select * From detail ";
  private final String SQL_INSERT="INSERT INTO `detail` (`anneeScolaire`, `professeur`, `classe`) VALUES ( ?, ?, ?);";
     private final String SQL_SELECT_BY_PROF_AND_YEAR="SELECT * FROM detail WHERE `detail`.`anneeScolaire` = ? AND `detail`.`professeur` = ?";
 
  private MySqlDB mysql;
  
  public DetailDao(){
      mysql=new MySqlDB();
  }
    @Override
    public int create(Detail obj) {
          int result=0;
        try {
              mysql.initPS(SQL_INSERT);
              
              mysql.getPstm().setString(1, obj.getAnneeScolaire());
              mysql.getPstm().setInt(2, obj.getProfesseur().getId());
              mysql.getPstm().setInt(3, obj.getClasse().getId());
              
            
             
             //5 Execution de la requete
              mysql.executeMaj();
              //REturn ID client ID
              ResultSet rs=mysql.getPstm().getGeneratedKeys();
              if(rs.first())  result=rs.getInt(1);
             
        } catch (SQLException ex) {
            Logger.getLogger(DetailDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return result;
    }

    @Override
    public boolean update(Detail obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Detail> selectAll() {
        ProfesseurDao p = new ProfesseurDao();
        ClasseDao cd = new ClasseDao();
               ArrayList<Detail> details=null;
              
                    details =new ArrayList<Detail>(); 
            //PreparedStatement ps = cnx.prepareStatement(requete);
            mysql.initPS(SQL_ALL);
            ResultSet rs = mysql.executeSelect();
                   try {
                       while(rs.next()){
                           Detail detail=null ;
                           detail.setId(rs.getInt(1));
                           detail.setAnneeScolaire(rs.getString(2));
                           detail.setClasse(cd.selectById(rs.getInt(3)));
                           detail.setProfesseur(p.selectById(rs.getInt(4)));
                           
                           details.add(detail);
                       }    } catch (SQLException ex) {
                       Logger.getLogger(DetailDao.class.getName()).log(Level.SEVERE, null, ex);
                   } 
        return details;
    }

    @Override
    public Detail selectById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Detail selectByNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     public ArrayList<Detail> selectClasseByProf(String date, Professeur p) throws SQLException {
          ArrayList<Detail> dets = null;
          ClasseDao daoclass = new ClasseDao();
        dets = new ArrayList<Detail>();
              mysql.initPS(SQL_SELECT_BY_PROF_AND_YEAR);
              
              mysql.getPstm().setString(1, date);
              mysql.getPstm().setInt(2, p.getId());
              ResultSet rs = mysql.executeSelect();
              
              try {
                   
                       while(rs.next()){
                          Detail detail=null ;
                        detail.setId(rs.getInt(1));
                        detail.setAnneeScolaire(rs.getString(2));
                          List <Classe> lClasse = daoclass.selectAll() ;

                         for(int i = 0; i < lClasse.size (); i++){
                             if(lClasse.get(i).getId() == rs.getInt(3)){
                                 detail.setClasse(lClasse.get(i));  
                             }
                         }

                           dets.add(detail);
                       }    } catch (SQLException ex) {
                       Logger.getLogger(DetailDao.class.getName()).log(Level.SEVERE, null, ex);
                   } 
        return dets;
    }
}
