/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Classe;
import models.Professeur;

/**
 *
 * @author ASUS
 */
public class ClasseDao implements IDao <Classe> {

    private final String SQL_ALL="select * from `classe`";
    private final String SQL_INSERT="INSERT INTO `classe` (`libelle`) VALUES (?);";
     private final String SQL_SELECT_BY_PROF="SELECT * FROM classe WHERE `classe`.`professeur` = ? ";
 
    private MySqlDB mysql;
    
    public ClasseDao(){
        mysql = new MySqlDB();
    }
   
    @Override
    public int create(Classe obj) {
          int result = 0;
        try {
            mysql.initPS(SQL_INSERT);
            mysql.getPstm().setString(1, obj.getLibelle());
            
            result=mysql.executeMaj();
            
        } catch (SQLException ex) {
            Logger.getLogger(ClasseDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    @Override
    public boolean update(Classe obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Classe> selectAll() {
        ArrayList<Classe> classes = null;
        
        classes = new ArrayList<Classe>();
        mysql.initPS(SQL_ALL);
            ResultSet rs = mysql.executeSelect();
        try {
            while(rs.next()){
                Classe classe= new Classe();
                classe.setId(rs.getInt("id"));
                classe.setLibelle(rs.getString("libelle"));
              
                classes.add(classe);
                
            }   } catch (SQLException ex) {
            Logger.getLogger(ClasseDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return classes;
    }

    @Override
    public Classe selectById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Classe selectByNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
   
    
}
