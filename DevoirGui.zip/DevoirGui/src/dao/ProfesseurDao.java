/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Classe;
import models.Personne;
import models.Professeur;

/**
 *
 * @author ASUS
 */
public class ProfesseurDao implements IDao<Professeur>{

      private final String SQL_ALL="Select * From personne";
      private final String SQL_SELECT_BY_ID="SELECT * FROM personne WHERE `personne`.`id` = ?";
      private final String SQL_SELECT_BY_NUMERO="SELECT * FROM personne WHERE `personne`.`numero` = ?";
  private final String SQL_INSERT="INSERT INTO `personne` (`nom`, `prenom`, `dateNaissance`, `numero`, `grade`) VALUES ( ?, ?, ?, ?, ?);";
    
  private MySqlDB mysql;
  
  public ProfesseurDao(){
      mysql=new MySqlDB();
  }
    @Override
    public int create(Professeur obj) {
          int result=0;
        try {
              mysql.initPS(SQL_INSERT);
              
              mysql.getPstm().setString(1, obj.getNom());
              mysql.getPstm().setString(2, obj.getPrenom());
              mysql.getPstm().setString(3, obj.getDateNaissance());
              
              mysql.getPstm().setString(4, obj.getNumero());
              mysql.getPstm().setString(5, obj.getGrade());
             
             //5 Execution de la requete
              mysql.executeMaj();
              //REturn ID client ID
              ResultSet rs=mysql.getPstm().getGeneratedKeys();
              if(rs.first())  result=rs.getInt(1);
             
        } catch (SQLException ex) {
            Logger.getLogger(ProfesseurDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return result;
    }

    @Override
    public boolean update(Professeur obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Professeur> selectAll() {
        ArrayList<Professeur> profs = null;
        
        profs = new ArrayList<Professeur>();
        mysql.initPS(SQL_ALL);
            ResultSet rs = mysql.executeSelect();
        try {
            while(rs.next()){
                Professeur prof= new Professeur();
                prof.setId(rs.getInt("id"));
                prof.setNom(rs.getString("nom"));
                prof.setPrenom(rs.getString("prenom"));
                  prof.setGrade(rs.getString("grade"));
                profs.add(prof);
                
            }   } catch (SQLException ex) {
            Logger.getLogger(ClasseDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return profs;
    }

    @Override
    public Professeur selectById(int id) {
        Professeur pr = null;
          try {
              mysql.initPS(SQL_SELECT_BY_ID);
              
              mysql.getPstm().setInt(1, id);
              ResultSet rs = mysql.executeSelect();
              if(rs.first()){
                  pr = new Professeur();
                  pr.setId(rs.getInt("id"));
                  pr.setNumero(rs.getString("numero"));
                  pr.setNom(rs.getString("nom"));
                  pr.setPrenom(rs.getString("prenom"));
                  pr.setGrade(rs.getString("grade"));
                  return pr;
              }
          } catch (SQLException ex) {
              Logger.getLogger(ProfesseurDao.class.getName()).log(Level.SEVERE, null, ex);
          }
          return pr;
    }

    @Override
    public Professeur selectByNumero(String numero) {
        
        Professeur pr = null;
          try {
              mysql.initPS(SQL_SELECT_BY_NUMERO);
              
              mysql.getPstm().setString(1, numero);
              ResultSet rs = mysql.executeSelect();
              
              if(rs.first()){
                  pr = new Professeur();
                  pr.setId(rs.getInt("id"));
                  pr.setNumero(rs.getString("numero"));
                  pr.setNom(rs.getString("nom"));
                  pr.setPrenom(rs.getString("prenom"));
                  pr.setGrade(rs.getString("grade"));
                  return pr;
              }
          } catch (SQLException ex) {
              Logger.getLogger(ProfesseurDao.class.getName()).log(Level.SEVERE, null, ex);
          }
          return pr;
    }
    
    public ArrayList<Professeur> ListProfByNumero(String numero) throws SQLException {
        
        ArrayList<Professeur> profs = null;
        profs = new ArrayList<Professeur>();
              mysql.initPS(SQL_SELECT_BY_NUMERO);
              
              mysql.getPstm().setString(1, numero);
              ResultSet rs = mysql.executeSelect();
              
             try {
            while(rs.next()){
                Professeur prof= new Professeur();
                prof.setId(rs.getInt("id"));
                prof.setNom(rs.getString("nom"));
                prof.setPrenom(rs.getString("prenom"));
                  prof.setGrade(rs.getString("grade"));
                profs.add(prof);
                
            }   } catch (SQLException ex) {
            Logger.getLogger(ClasseDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return profs;
         
    }
    
}

