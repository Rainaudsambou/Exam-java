/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Etudiant;

/**
 *
 * @author ASUS
 */
public class EtudiantDao implements IDao<Etudiant> {

     private final String SQL_ALL="Select * From personne ";
  private final String SQL_INSERT="INSERT INTO `personne` (`nom`, `prenom`, `dateNaissance`, `numero`, `tuteur`) VALUES ( ?, ?, ?, ?, ?);";
     private final String SQL_SELECT_BY_ID="SELECT * FROM personne WHERE `personne`.`id` = ?";
 
  private MySqlDB mysql;
  
  public EtudiantDao(){
      mysql=new MySqlDB();
  }
    @Override
    public int create(Etudiant obj) {
         int result=0;
        try {
              mysql.initPS(SQL_INSERT);
              
              mysql.getPstm().setString(1, obj.getNom());
              mysql.getPstm().setString(2, obj.getPrenom());
              mysql.getPstm().setString(3, obj.getDateNaissance());
              
              mysql.getPstm().setString(4, obj.getNumero());
              mysql.getPstm().setString(5, obj.getTuteur());
             
             //5 Execution de la requete
              mysql.executeMaj();
              //REturn ID client ID
              ResultSet rs=mysql.getPstm().getGeneratedKeys();
              if(rs.first())  result=rs.getInt(1);
             
        } catch (SQLException ex) {
            Logger.getLogger(EtudiantDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return result;
    }

    @Override
    public boolean update(Etudiant obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Etudiant> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Etudiant selectById(int id) {
        Etudiant pr = null;
          try {
              mysql.initPS(SQL_SELECT_BY_ID);
              
              mysql.getPstm().setInt(1, id);
              ResultSet rs = mysql.executeSelect();
              if(rs.first()){
                  pr = new Etudiant();
                  pr.setId(rs.getInt("id"));
                  pr.setNumero(rs.getString("numero"));
                  pr.setNom(rs.getString("nom"));
                  pr.setPrenom(rs.getString("prenom"));
                  pr.setTuteur(rs.getString("tuteur"));
                  return pr;
              }
          } catch (SQLException ex) {
              Logger.getLogger(ProfesseurDao.class.getName()).log(Level.SEVERE, null, ex);
          }
          return pr;
    }

    @Override
    public Etudiant selectByNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
