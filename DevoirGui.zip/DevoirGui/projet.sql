-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  sam. 18 avr. 2020 à 21:42
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projetsali`
--

-- --------------------------------------------------------

--
-- Structure de la table `classe`
--

DROP TABLE IF EXISTS `classe`;
CREATE TABLE IF NOT EXISTS `classe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `classe`
--

INSERT INTO `classe` (`id`, `libelle`) VALUES
(1, 'LIAGE'),
(2, 'MAE'),
(3, ''),
(4, 'TTL');

-- --------------------------------------------------------

--
-- Structure de la table `detail`
--

DROP TABLE IF EXISTS `detail`;
CREATE TABLE IF NOT EXISTS `detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anneeScolaire` varchar(255) NOT NULL,
  `professeur` int(11) NOT NULL,
  `classe` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `detail`
--

INSERT INTO `detail` (`id`, `anneeScolaire`, `professeur`, `classe`) VALUES
(1, '2019', 11, 1);

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

DROP TABLE IF EXISTS `inscription`;
CREATE TABLE IF NOT EXISTS `inscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL,
  `anneScolaire` varchar(255) NOT NULL,
  `classe` int(11) NOT NULL,
  `etudiant` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `inscription`
--

INSERT INTO `inscription` (`id`, `date`, `anneScolaire`, `classe`, `etudiant`) VALUES
(1, '18-04-2020', '2018/2019', 2, 16);

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

DROP TABLE IF EXISTS `personne`;
CREATE TABLE IF NOT EXISTS `personne` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `dateNaissance` varchar(255) NOT NULL,
  `numero` varchar(255) NOT NULL,
  `tuteur` varchar(255) DEFAULT NULL,
  `grade` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `personne`
--

INSERT INTO `personne` (`id`, `nom`, `prenom`, `dateNaissance`, `numero`, `tuteur`, `grade`) VALUES
(1, 'Test', 'Test', '', 'ETU-486597-04-2020', 'Test', NULL),
(2, 'Test', 'test', '', 'ETU-163853-04-2020', 'tes', NULL),
(3, 'essaie', 'essaie', '', 'ETU-119658-04-2020', 'essaie', NULL),
(4, 'aa', 'aaa', '', 'ETU-259096-04-2020', 'aaa', NULL),
(5, 'gdb', 'gfb', '', 'ETU-233515-04-2020', 'fb', NULL),
(6, 'gdb', 'gfb', '', 'ETU-233515-04-2020', 'fb', NULL),
(7, 'gfb', 'edqc', '', 'ETU-450065-04-2020', 'f', NULL),
(8, 'test', 'reussi ', '', 'ETU-149669-04-2020', 'par force', NULL),
(9, 'Et Merce', 'Its ', '', 'ETU-683322-04-2020', 'Okay', NULL),
(10, 'aaa', 'aaa', '', 'ETU-903476-04-2020', 'aaa', NULL),
(11, 'Nguer', 'Mor', '', 'essai', 'Debutant', NULL),
(12, 'bou ', 'bakh bi ', '', 'ETU-618849-04-2020', 'test', NULL),
(13, 'essai', 'essai', '', 'ETU-159047-04-2020', 'essai', NULL),
(14, 'zdfd', 'vfbeth', '', 'ETU-254968-04-2020', 'bfvg h', NULL),
(15, 'efvy', 'grbth', '', 'ETU-266440-04-2020', 'f vbrg', NULL),
(16, 'fnbg', 'jiveg', '', 'ETU-572066-04-2020', 'ji ev', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
